/* SINDI'S LIGHTBOX SCRIPT (unchanged) */
/* scripts.js - Lightbox for Browse + Portfolio */

/* ================================
   UNIVERSAL LIGHTBOX FOR ALL PAGES
=================================== */

(() => {
  const imgs = Array.from(document.querySelectorAll(".lightbox-img"));
  if (!imgs.length) return;

  const lightbox = document.getElementById("lightbox");
  const lightboxImg = document.getElementById("lightbox-img");
  const captionEl = document.getElementById("lightbox-caption");
  const nextBtn = document.getElementById("next");
  const prevBtn = document.getElementById("prev");
  const closeBtn = document.getElementById("lb-close");

  let currentIndex = 0;

  function getCaption(img) {
    return img.dataset.caption || img.alt || "";
  }

  function show(index) {
    currentIndex = (index + imgs.length) % imgs.length;
    lightboxImg.src = imgs[currentIndex].src;
    captionEl.textContent = getCaption(imgs[currentIndex]);
  }

  imgs.forEach((img, i) => {
    img.addEventListener("click", () => {
      show(i);
      lightbox.classList.add("show");
      document.body.style.overflow = "hidden";
    });
  });

  nextBtn.onclick = () => show(currentIndex + 1);
  prevBtn.onclick = () => show(currentIndex - 1);
  closeBtn.onclick = () => close();

  function close() {
    lightbox.classList.remove("show");
    document.body.style.overflow = "";
  }

  lightbox.addEventListener("click", e => {
    if (e.target === lightbox) close();
  });

  document.addEventListener("keydown", e => {
    if (!lightbox.classList.contains("show")) return;

    if (e.key === "ArrowRight") nextBtn.click();
    if (e.key === "ArrowLeft") prevBtn.click();
    if (e.key === "Escape") close();
  });
})();



/* ================================
   BOOKING FORM FEEDBACK MESSAGE
=================================== */

(() => {

  const form = document.querySelector("form");
  const success = document.getElementById("booking-success");

  if (!form || !success) return; // only works on bookings page

  form.addEventListener("submit", e => {
    e.preventDefault();

    success.style.display = "block";

    setTimeout(() => {
      success.style.display = "none";
      form.reset();
    }, 2500);
  });

})();

