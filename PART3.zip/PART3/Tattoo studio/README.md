#part3 improvement 
STUDENT NAME: SINDISWA
STUDENT SURNAME: MORRIS
STUDENT NUMBER: ST10469876
MODULE: WEB DEVELOPMENT
STUDENT CODE: WEDE5020
 
HOMEPAGE
When you minimize the picture that is on the homepage the video that is at the bottom of that picture is going to be next to the picture. You can make the video play into picture-in-picture. You can also translate the audio, when the video is played in picture-in-picture mode you can also press” X” that is on the right which will close the picture-in-picture. You can press the back to tab, you can also pause the video whilst on the picture-in-picture mode and the video call also be unmuted and muted. There are also settings that allows the user to allow permission on whether the video can play into picture-in-picture mode and you can right click to context menu of the video player to get into picture-in-picture.
BROWSE
The pictures have light box and when you put your arrow on one of those pictures, the picture is going to go up and when you view it is going to be displayed in the middle of the screen and it will show arrows on the left and right side that can take you to the previous and next picture and at the bottom there will be written what kind of a tattoo it is and where it is placed in that specific picture, for example. Collarbone-delicate line work.
You can also press the “X” which will be to close viewing the pictures on browse and that “X” is on the right top of that specific viewed picture.
PORTFOLIO
Picture goes up when the arrow is placed on top of it, which is placed they also have a light box and the heading on what kind of a tattoo they are is on the left top it’s no longer in the middle.
CONTACT US
You can register when you are a new user on the contact us page, click submit when you are done filling in the space and can also clear the filled in details if they are incorrect or when you’ve made a mistake.
MAP DISPLAY:
Pop-up map is the street map. Left top is the address and you can view the directions of where Morrisspire is located but it’s going to take you to Google Maps. Left bottom is a small square that you should press if you want to view satellite imagery/directions.
Right bottom are map camera controls:
< = Move left
> = Move Right
↑= Move up
↓=Move down
- = Zoom out
+ = Zoom in
Control + to scroll to zoom the map
BOOKINGS
Fill in your details to schedule a tattoo consultation or appointment, then click “SUBMIT BOOKINGS” after that you are going to get feedback that says:
YOUR BOOKING HAS BEEN RECEIVED. WE WILL CONTACT YOU SOON.
REFERENCES
SS Flexbox: CSS-Tricks Flexbox Guide
CSS Media Queries: MDN Web Docs - Media Queries
Hamburger Menu Implementation: W3Schools - Hamburger Menu
CSS Transitions and Hover Effects: MDN Web Docs - Transitions
Responsive Design Basics: Google Web Fundamentals
MDN Web Docs - Event Handling
MDN Event Handling
CSS Tricks - How to Create a Lightbox with Vanilla JavaScript
CSS Tricks Lightbox Tutorial
W3Schools - How to Create a Lightbox
W3Schools Lightbox Example
CSS-Tricks - CSS Transitions
CSS-Tricks Transition Tutorial
MDN Web Docs - CSS Transforms
MDN CSS Transform
A List Apart - The Science of Hover Effects
A List Apart Hover Effects
MDN Web Docs - Keyboard Event Handling
MDN Keyboard Events

JavaScript.info - Events
JavaScript Events
