// Initialize EmailJS with your public key
(function() {
  emailjs.init("Ag5iEGlD0KDJj9UW2"); // Your public key
})();

// Handle form submission
document.getElementById("registerForm").addEventListener("submit", function(event) {
  event.preventDefault();

  // Collect form data
  const formData = {
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    password: document.getElementById("password").value,
  };

  // Send email using EmailJS
  emailjs.send("zqxtrsk", "template_zh6lshj", formData)
    .then(function(response) {
      console.log("SUCCESS", response);
      alert("Registration successful! You’ll receive a confirmation email shortly.");
    }, function(error) {
      console.log("FAILED", error);
      alert("There was an issue with your registration. Please try again.");
    });
});
